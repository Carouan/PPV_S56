







## <u>core.py</u>




## <u>discord_bot_commands.py</u>
	Cog : EmailCog
		send_daily_summary
	Cog : MessagesCog
		list_messages()



### mails_management.py
	format_messages_for_email(messages_dict)
	send_email(body, from_addr, password, to_addr)


### summarizer.py
	format_messages_by_day(messages_dict)









Salons importants

#général





https://github.com/Nauorac/discordbot_coalffj

Bot discord qui résume les nouveau message du serveur Coalition FFJ et les envois par mail sur coalition_ffj@femmesdedroit.be (mailing list)

Bot discord visant à envoyer un résumé quotidien des messages postés dans le serveur Coalition Feminists for Justice vers une adresse e-mail.
Adresse e-mail : coalition_ffj@femmesdedroit.be  (mailing list gérée sur l'hébergement OVH de FDD)



https://railway.com/dashboard

----
# Discord 

https://discord.com/developers/applications/1331192031275389010/oauth2

https://discord.com/developers/applications/1331192031275389010/information
### Client information

Client ID : 1331192031275389010
Client Secret : MayVDrmLJrSP9hdyenHzgTW_Dj2kfVg8
Application ID : 1331192031275389010
Public Key : 58fa342559aa96f1e62b0e228f7034c8d1f048346896bd0223cac387b88bec95

https://github.com/aeither/discord-python
	https://github.com/Nauorac/discord-python



***

# Railway 

## Doc : https://docs.railway.com/



----
---
---


************************************************************************************************
DISCORD BOT TO SUMMARIZE AND SEND A DAILY REPORT TO COALITION_FFJ@FEMMESDEDROIT.BE MAILING-LIST
************************************************************************************************
Bot discord qui résume les nouveau message du serveur Coalition FFJ et les envois par mail sur coalition_ffj@femmesdedroit.be (mailing list)


- Bot hébergé sur Railway (https://railway.com/)
- Code sur le repo GitHub : https://github.com/Nauorac/discordbot_coalffj.git


*********************************
ICT_BOT@femmesdedroit.be
Mdp : 52!WsMc43Bs$
******************************
Mailing-list : coalition_ffj@femmesdedroit.be
****************************************************
Personnalisation avancée :
Les valeurs précisées ci-dessous sont des exemples. 
Prenez soin de les remplacer par vos propres valeurs.

Vous pouvez personnaliser la plupart des textes de votre mailing list. 
En tant que modérateur, vous devez envoyer un e-mail vide à nom_de_votre_ML-edit@mydomain.ovh.

Exemple : Votre mailing list est newsletter@mydomain.ovh. 
Depuis votre adresse e-mail modérateur, il vous faudra envoyer un message à newsletter-edit@mydomain.ovh.
Vous recevrez alors un e-mail qui vous guidera pour effectuer vos modifications.

Ci-dessous, une liste des fichiers contenant les textes de réponses et une brève description de l'utilisation de leur contenu. 
Pour éditer un fichier, envoyez simplement un message à envoi-edit.fichier, en substituant le nom du fichier à 'fichier'. 
Les instructions d'édition seront envoyées avec le fichier de texte.

Fichier				Utilisation

bottom				pied de page de toutes les réponses : infos générales.
digest				section 'administrative' des bulletins periodiques.
faq					réponses aux questions fréquentes au sujet de cette liste.
get_bad				dans le cas de messages absents des archives.
help				aide générale (entre 'top' et 'bottom').
info				informations sur la liste. La première ligne en est un résumé.
mod_help			aide spécifique aux modérateurs de liste.
mod_reject			à l'expéditeur d'envois refusés.
mod_request			aux modérateurs avec un envoi.
mod_sub				à l'abonné après confirmation d'inscription du modérateur.
mod_sub_confirm		aux modérateurs pour valider une inscription.
mod_timeout			à l'expéditeur d'un message non valide depuis longtemps.
mod_unsub_confirm	à un administrateur pour demander une désinscription.
sub_bad				à l'abonné si la confirmation était mauvaise.
sub_confirm			à l'abonné pour confirmer sa requête.
sub_nop				à l'abonné après une nouvelle inscription.
sub_ok				à l'abonné après un abonnement réussi.
top					en-tête de chaque réponse.
trailer				ajouté à la fin de chaque contribution à la liste.
unsub_bad			à l'abonné si la confirmation de désinscription est fausse.
unsub_confirm		à l'abonné pour demander confirmation de désinscription.
unsub_nop			à un non-abonné après une demande de désabonnement.
unsub_ok			à un ex-abonné après une désinscription réussie.

Exemple : Si vous souhaitez modifier le pied de page par défaut des e-mails envoyés à votre mailing list, 
il vous faudra envoyer un message à l'adresse nom_de_votre_ML-edit.bottom@mydomain.ovh. 
Vous recevrez alors un nouvel e-mail vous expliquant comment personnaliser le pied de page.






